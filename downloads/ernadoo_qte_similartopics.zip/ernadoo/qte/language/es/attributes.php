<?php
/**
 *
 * @package Quick Title Edition Extension
 * @copyright (c) 2015 ABDev
 * @copyright (c) 2015 PastisD
 * @copyright (c) 2015 Geolim4 <http://geolim4.com>
 * @copyright (c) 2015 Zoddo <zoddo.ino@gmail.com>
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

// ignore
if (!defined('IN_PHPBB'))
{
	exit;
}

// init lang ary, if it doesn't !
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'QTE_CAN_USE_ATTR'	=> 'Puede usar la etiqueta %s',

	// select
	'QTE_ATTRIBUTES' => 'Etiquetas de Tema',
	'QTE_ATTRIBUTE' => 'Etiqueta de Tema',

	'QTE_ATTRIBUTE_ADD' => 'Seleccione una etiqueta de tema',
	'QTE_ATTRIBUTE_REMOVE' => 'Eliminar etiqueta del tema',
	'QTE_ATTRIBUTE_DESIRED' => 'Seleccione la etiqueta deseada',
	'QTE_ATTRIBUTE_KEEP' => 'Mantener la etiqueta actual',

	// notifications
	'QTE_ATTRIBUTE_ADDED' => 'Se ha aplicado una etiqueta al título del tema',
	'QTE_ATTRIBUTE_UPDATED' => 'La etiqueta de ese tema ha sido actualizada',
	'QTE_ATTRIBUTE_REMOVED' => 'La etiqueta de tema ha sido eliminada',

	'QTE_TOPIC_ATTRIBUTE_ADDED' => 'Se ha aplicado la etiqueta al tema seleccionado',
	'QTE_TOPICS_ATTRIBUTE_ADDED' => 'Se ha aplicado la etiqueta a los temas seleccionados',
	'QTE_TOPIC_ATTRIBUTE_UPDATED' => 'La etiqueta del tema seleccionada ha sido actualizada',
	'QTE_TOPICS_ATTRIBUTE_UPDATED' => 'La etiqueta de los temas seleccionados han sido actualizadas',
	'QTE_TOPIC_ATTRIBUTE_REMOVED' => 'La etiqueta del tema seleccionado ha sido eliminada',
	'QTE_TOPICS_ATTRIBUTE_REMOVED' => 'La etiqueta de los temas seleccionados han sido eliminadas',

	// search
	'QTE_ATTRIBUTE_SELECT' => 'Seleccione una etiqueta de tema',
	'QTE_ATTRIBUTE_SEARCH' => 'Buscar por etiquetas',
	'QTE_ATTRIBUTE_SEARCH_EXPLAIN' => 'Seleccione la etiqueta que desea buscar',

	// sort
	'QTE_SORT' => 'Como etiqueta',
	'QTE_ALL' => 'Todo',

	// mistake messages
	'QTE_ATTRIBUTE_UNSELECTED' => '¡Debe seleccionar una etiqueta!',

	// placeholders
	'QTE_KEY_USERNAME' => '¦user¦',
	'QTE_KEY_DATE' => '¦date¦',
));

// Topic attributes as keys
$lang = array_merge($lang, array(
	'QTE_SOLVED' => '[Solucionado por %mod% :: %date%]',
	'QTE_CANCELLED' => 'Cancelado',
	
/* Atributos - PSMKaraoke */	
	'QTE_REUP'   => 'RESUBIDO',
	'QTE_ROTO'   => 'ENLACE ROTO',
	'QTE_LAUT'   => 'LISTADO AUTOMATICO',
	'QTE_LVPINT' => 'LISTADO ZONA VIP & INT.',
));
