<?php
/**
 *
 * @package Quick Title Edition Extension
 * @copyright (c) 2015 ABDev
 * @copyright (c) 2015 PastisD
 * @copyright (c) 2015 Geolim4 <http://geolim4.com>
 * @copyright (c) 2015 Zoddo <zoddo.ino@gmail.com>
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

// ignore
if (!defined('IN_PHPBB'))
{
	exit;
}

// init lang ary, if it doesn't !
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACL_A_ATTR_MANAGE'		=> 'Puede gestionar etiquetas de tema',
	'ACL_M_ATTR_DEL'		=> 'Puede borrar etiquetas',
	'ACL_M_ATTR_EDIT'		=> 'Puede editar etiquetas',

	'ACL_CAT_QTE'			=> 'QTE',
));
