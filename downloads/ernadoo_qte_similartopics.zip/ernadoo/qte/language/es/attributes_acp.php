<?php
/**
 *
 * @package Quick Title Edition Extension
 * @copyright (c) 2015 ABDev
 * @copyright (c) 2015 PastisD
 * @copyright (c) 2015 Geolim4 <http://geolim4.com>
 * @copyright (c) 2015 Zoddo <zoddo.ino@gmail.com>
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

// ignore
if (!defined('IN_PHPBB'))
{
	exit;
}

// init lang ary, if it doesn't !
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// administration
$lang = array_merge($lang, array(
	'QTE_ADD' => 'Agregar una nueva etiqueta',
	'QTE_ADD_EXPLAIN' => 'Aquí puede definir los nuevos campos de la etiqueta.',
	'QTE_EDIT' => 'Editar la etiqueta',
	'QTE_EDIT_EXPLAIN' => 'Aquí puede modificar los nuevos campos de la etiqueta.',

	'QTE_FIELDS' => 'Campos de la etiqueta',
	'QTE_TYPE' => 'Tipo de etiqueta',
	'QTE_TYPE_TXT' => 'Texto',
	'QTE_TYPE_IMG' => 'Imagen',
	'QTE_NAME' => 'Nombre de etiqueta',
	'QTE_NAME_EXPLAIN' => '- Usar una constante de idioma si  el nombre es servido por un archivo de idioma, o insertar directamente el nombre de la etiqueta.<br />- Introducir <strong>%%mod%%</strong> mostrará el nombre de usuario que le puso la etiqueta al tema.<br />- Introducir <strong>%%date%%</strong> mostrará el dia en el que la etiqueta se aplicó al tema.<br /><br />- Ejemplo : <strong>[Solucionado por %%mod%%]</strong> mostrará <strong>[Solucionado por %s]</strong>',
	'QTE_DESC' => 'Descripción de la etiqueta',
	'QTE_DESC_EXPLAIN' => 'Puede introducir un comentario corto que se usuará para diferenciar etiquetas que tengas el mismo nombre.',
	'QTE_IMG' => 'Attribute image',
	'QTE_IMG_EXPLAIN' => 'You can use the image name if it is served in the imageset, or seize the relative path of the image.',
	'QTE_DATE' => 'Formato de la fecha de la etiqueta',
	'QTE_DATE_EXPLAIN' => 'La sintaxis utilizado es idéntica a la de la función <a href="http://www.php.net/date">date()</a> de PHP.',
	'QTE_COLOUR' => 'Color de la etiqueta',
	'QTE_COLOUR_EXPLAIN' => 'Selecione un valor del <strong>selector de color</strong>, o introdúcelo directamente.',
	'QTE_USER_COLOUR' => 'Colorear el usuario que aplicó la etiqueta',
	'QTE_USER_COLOUR_EXPLAIN' => 'Si usa el argumento <strong>%mod%</strong> y esa opción está activada el color del grupo del usuario será aplicado.',
	'QTE_COPY_AUTHS' => 'Copiar permisos de',
	'QTE_COPY_AUTHS_EXPLAIN' => 'Si decide copiar los permisos, la etiqueta tendrá el mismo permiso que la que tu seleciones. Esto sobrescribirá cualquier permisos que hayas puesto a esta etiqueta anteriormente con los permisos de la etiqueta seleccionada. Si seleccionas la opción <strong>Personalizada</strong>, los permisos actuales se mantendrán.',

	'QTE_ALLOWED_GROUPS' => 'Grupos autorizados',
	'QTE_ALLOWED_GROUPS_EXPLAIN' => 'Grupos que están autorizados para usar esta etiqueta.<br />Seleccione múltiplos grupos manteniendo <samp>CTRL</samp> o <samp>COMMAND</samp> y haciendo click.',
	'QTE_ALLOWED_AUTHOR' => 'Autorizar al autor del tema usar la etiqueta en los foros seleccionados',
	'QTE_ALLOWED_AUTHOR_EXPLAIN' => 'Si esa opción está activada, el autor del tema podrá usar la etiqueta, incluso si no es miembro de los grupos seleccionados.',
	'QTE_COPY_PERMISSIONS' => 'Copiar permisos de la etiqueta de',
	'QTE_COPY_PERMISSIONS_EXPLAIN' => 'Una vez creado, el foro tendrá los mismos permisos de la etiqueta que el que seleccionó. Si no se selecciona ningún foro, las etiquetas no se mostrarán mientras que sus permisos no se hayan definido.',

	'QTE_AUTH_ADD' => 'Agregar un permiso',
	'QTE_AUTH_REMOVE' => 'Eliminado un permiso',
	'QTE_AUTH_NO_PERMISSIONS' => 'No copiar los permisos',

	'QTE_ATTRIBUTE' => 'Etiqueta',
	'QTE_ATTRIBUTES' => 'Etiquetas',
	'QTE_USAGE' => 'Uso',

	'QTE_CSS' => 'Probablemente manejada por CSS',
	'QTE_NONE' => 'N/A',

	'QTE_MUST_SELECT' => 'You must select an attribute.',
	'QTE_NAME_ERROR' => 'The “Attribute name” field seems to be empty.',
	'QTE_DESC_ERROR' => 'The “Attribute description” field seems to be too long.',
	'QTE_COLOUR_ERROR' => 'The “Attribute colour field seems to contain a mistake.',
	'QTE_DATE_ARGUMENT_ERROR' => 'You have defined a date format. But you have not defined the <strong>%date%</strong> argument inside your attribute.',
	'QTE_DATE_FORMAT_ERROR' => 'You have defined the <strong>%date%</strong> argument inside your attribute. But you have not defined the date format.',
	'QTE_USER_COLOUR_ERROR' => 'You have enabled which ensures to colour the username. But you have not defined the <strong>%mod%</strong> argument inside your attribute.',
	'QTE_FORUM_ERROR' => 'You cannot specify a category or a forum link.',

	'QTE_ADDED' => 'A new attribute has been added.',
	'QTE_UPDATED' => 'The selected attribute has been updated.',
	'QTE_REMOVED' => 'The selected attribute has been deleted.',

	'QTE_MIGRATIONS_OUTDATED' => 'Your database is not up to date.<br />Please disable and re-enable the extension in order to update it.<br /><br />Database version: %1$s<br />Files version: %2$s',
));

// forums
$lang = array_merge($lang, array(
	'QTE_TOPICS_ATTR_SETTINGS' => 'Ajustes de la etiqueta',

	'QTE_DEFAULT_ATTR' => 'Etiqueta por defecto del foro',
	'QTE_DEFAULT_ATTR_EXPLAIN' => 'La etiqueta seleccionada se aplicará cuando se cree un nuevo tema, independientemente de los permisos del usuario..',
	'QTE_FORCE_USERS' => 'Forzar a los usuarios a aplicar una etiqueta a su tema:',
	'QTE_FORCE_USERS_EXPLAIN' => 'Si está habilitado, los usuarios tendrán que seleccionar una etiqueta para su tema en ese foro.',
));
