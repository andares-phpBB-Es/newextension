<?php
/**
 *
 * @package Quick Title Edition Extension
 * @copyright (c) 2015 ABDev
 * @copyright (c) 2015 PastisD
 * @copyright (c) 2015 Geolim4 <http://geolim4.com>
 * @copyright (c) 2015 Zoddo <zoddo.ino@gmail.com>
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

// ignore
if (!defined('IN_PHPBB'))
{
	exit;
}

// init lang ary, if it doesn't !
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// moderation
$lang = array_merge($lang, array(
	// logs
	'LOG_ATTRIBUTE_ADDED' => '<strong>Añadida una nueva etiqueta</strong><br />» %s',
	'LOG_ATTRIBUTE_UPDATED' => '<strong>Etiqueta actualizada</strong><br />» %s',
	'LOG_ATTRIBUTE_REMOVED'	=> '<strong>Etiqueta borrada</strong><br />» %s',
	'LOG_ATTRIBUTE_MOVE_DOWN'	=> '<strong>Una etiqueta movida</strong> %1$s <strong>debajo de</strong> %2$s',
	'LOG_ATTRIBUTE_MOVE_UP'	=> '<strong>Una etiqueta movida</strong> %1$s <strong>encima de</strong> %2$s',

	'MCP_ATTRIBUTE_ADDED' => '<strong>Añadida una nueva etiqueta al tema</strong><br />» %s',
	'MCP_ATTRIBUTE_UPDATED' => '<strong>Etiqueta actualizada para el tema</strong><br />» %s',
	'MCP_ATTRIBUTE_REMOVED'	=> '<strong>Etiqueta borrada del tema</strong><br />» %s',
));
